﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace pd1app
{

    class Program
    {
        static int addProductCount = 0;
        static float discount = 0;
        static string[] rateApp = { "Excellent", "Good", "Normal", "Fair" };
        static int[] rateArray = new int[30];
        static int count2 = 0;
        static string[] feedback = new string[30];
        static int count1 = 0;
        static int[] price1 = new int[30];
        static int[] stock = new int[30];
        static string[] name1 = new string[30];
        static string[] username = new string[100];
        static string[] password = new string[100];
        static string[] role = new string[100];
        static int count = 0;

        static void Main()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Logo();
            System.Threading.Thread.Sleep(1700);

            GetFeedback(feedback, ref count1);
            GetRate(rateArray, ref count2);
            GetDiscount(ref discount);
            GetUserData(ref username, ref password, ref role, ref count);
            GetProductData(ref name1, ref price1, ref stock, ref addProductCount);

            while (true)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Header();
                string output = Login();

                if (output == "1")
                {
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("                                 _^^........|   SIGN UP   |........^^_                                   ");
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Cyan;

                    bool check = false;
                    string name, pass;
                    Console.Write("Enter your Username: ");
                    name = Console.ReadLine();
                    Console.Write("Enter your password (greater than 3 digits): ");
                    pass = Console.ReadLine();

                    check = Signup(name, pass, ref count, username);

                    /*for (int x = 0; x < 15; x++)
                    {
                        if (name[x] == ' ' || pass[x] == ' ')
                        {
                            Console.WriteLine("Don't use space....");
                            Console.ReadKey();
                            check = true;
                        }
                    }*/

                    if (pass.Length <= 3)
                    {
                        Console.WriteLine("Invalid password...");
                        check = true;
                    }

                    while (true)
                    {
                        if (!check)
                        {
                            string checkRole;
                            Console.Write("Enter your Role (Admin or Customer): ");
                            checkRole = Console.ReadLine();

                            if (checkRole.Equals("admin", StringComparison.OrdinalIgnoreCase) || checkRole.Equals("customer", StringComparison.OrdinalIgnoreCase))
                            {
                                role[count] = checkRole;
                                username[count] = name;
                                password[count] = pass;
                                count++;
                                Console.WriteLine("Successfully Sign up :)_...");
                                Console.WriteLine();
                                SaveUserData(username, password, role, count);
                            }
                            else
                            {
                                Console.WriteLine("Invalid Role (Just only admin or customer)");
                            }

                            break;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                else if (output == "2")
                {
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("                                 _^^........|   SIGN IN   |........^^_                                   ");
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Cyan;

                    string name, pass;
                    Console.Write("Enter your Username: ");
                    name = Console.ReadLine();
                    Console.Write("Enter your password: ");
                    pass = Console.ReadLine();

                    string output1;

                    while (true)
                    {
                        output1 = Signin(name, pass, username, password, role);

                        if (output1 != "invalid")
                        {
                            if (output1.Equals("Customer", StringComparison.OrdinalIgnoreCase))
                            {
                                Console.WriteLine("Successfully Sign In....");
                                Console.ReadKey();
                                Menu(price1, name1, count, username, password, role, stock, feedback, ref count1, rateApp, rateArray, ref count2, ref discount, ref addProductCount);
                                break;
                            }
                            else if (output1.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                            {
                                Console.WriteLine("Successfully Sign In....");
                                Console.ReadKey();
                                Admin(price1, name1, count, username, password, role, stock, feedback, ref count1, rateApp, rateArray, ref count2, ref discount, ref addProductCount);
                                break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Invalid Username or Password");
                            break;
                        }
                    }
                }
                else if (output == "3")
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Invalid input.....");
                    Console.WriteLine("Enter 1, 2, or 3 only.");
                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue... ");
                    Console.ReadKey();
                    continue;
                }

                Console.WriteLine("Press any key to continue... ");
                Console.ReadKey();
            }
        }
        static string Login()
        {
            Console.Clear();
            Header();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("                                 _^^........|   LOGIN   |........^^_                                   ");
            Console.WriteLine();

            Console.WriteLine("Select one of the following option...");
            Console.WriteLine("1. Sign Up ");
            Console.WriteLine("2. Sign In ");
            Console.WriteLine("3. Exit ");

            string option = Console.ReadLine();
            return option;
        }
        static void Header()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("*******************************************************************************************************");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("*                                       BFC  Restaurant  System                                       *");
            Console.WriteLine("*                                           Township Lahore                                           *");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("*******************************************************************************************************");
            Console.WriteLine();
            Console.ResetColor();
        }
        static bool Signup(string name, string pass, ref int count, string[] username)
        {
            for (int x = 0; x < count; x++)
            {
                if (name == username[x])
                {
                    Console.WriteLine("Username Already Exist...");
                    return true;
                }
            }
            return false;
        }

        static string Signin(string name, string pass, string[] username, string[] password, string[] role)
        {
            string sendRole = "invalid";
            for (int x = 0; x < 30; x++)
            {
                if (name == username[x] && pass == password[x] && password[x].Length >= 4)
                {
                    sendRole = role[x];
                    break;
                }
            }
            return sendRole;
        }
        static void Logo()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"
                                                                                                            
                                                                                                            
                                                                                                            
                                                                                                            
                                                                                                            
                                                                                                            
                 ____   ______ ______   ____               __                                     __        
                / __ ) / ____// ____/  / __ \ ___   _____ / /_ ____ _ __  __ _____ ____ _ ____   / /_       
               / __  |/ /_   / /      / /_/ // _ \ / ___// __// __ `// / / // ___// __ `// __ \ / __/       
              / /_/ // __/  / /___   / _, _//  __/(__  )/ /_ / /_/ // /_/ // /   / /_/ // / / // /_         
             /_____//_/     \____/  /_/ |_| \___//____/ \__/ \__,_/ \__,_//_/    \__,_//_/ /_/ \__/         
                                                                                                            
                 ______                              __     _           __           __                     
                /_  __/____  _      __ ____   _____ / /_   (_)____     / /   ____ _ / /_   ____   _____ ___ 
                 / /  / __ \| | /| / // __ \ / ___// __ \ / // __ \   / /   / __ `// __ \ / __ \ / ___// _ \
                / /  / /_/ /| |/ |/ // / / /(__  )/ / / // // /_/ /  / /___/ /_/ // / / // /_/ // /   /  __/
               /_/   \____/ |__/|__//_/ /_//____//_/ /_//_// .___/  /_____/\__,_//_/ /_/ \____//_/    \___/ 
                                                          /_/                                               
");
            Console.ResetColor();
        }



        static string CustomerMenu(ref float discount)
        {
            string option;

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("                                 _^^........|   MENU   |........^^_                                   ");
            Console.WriteLine();

            if (discount > 0)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"\tDiscount is: {discount}%");
                Console.WriteLine();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\tDiscount is: {discount}%");
                Console.WriteLine();
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Select one of the following option number...");
            Console.WriteLine("1.   [Cripsy Items]");
            Console.WriteLine("2.   [Burgers & Snacks]");
            Console.WriteLine("3.   [Beverage]");
            Console.WriteLine("4.   [Siders]");
            Console.WriteLine("5.   To Order...");
            Console.WriteLine("6.   Feedback...");
            Console.WriteLine("7.   Change Password...");
            Console.WriteLine("8.   Logout...");
            Console.Write("Your option: ");

            option = Console.ReadLine();
            return option;
        }

        static string AdminMenu(int[] stock, ref int addProductcount)
        {
            bool check = true;
            string choice;

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("                                 _^^........|   ADMIN   |........^^_                                   ");
            Console.WriteLine();

            Console.WriteLine("1. Veiw Products...");

            for (int x = 0; x < addProductcount; x++)
            {
                if (stock[x] <= 10)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("2. See Stocks...");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    check = false;
                }
            }

            if (check)
            {
                Console.WriteLine("2. See Stocks...");
            }

            Console.WriteLine("3. Add discount...");
            Console.WriteLine("4. Remove discount...");
            Console.WriteLine("5. See FeedBack...");
            Console.WriteLine("6. Check Ratings...");
            Console.WriteLine("7. Change Password...");
            Console.WriteLine("8. Change Price of the product...");
            Console.WriteLine("9. Add Product");
            Console.WriteLine("10. Add Stock");
            Console.WriteLine("11. Logout");
            Console.Write("Your option: ");
            Console.WriteLine();

            choice = Console.ReadLine();
            return choice;
        }

        static bool CheckDiscount(ref float discount)
        {
            if (discount <= 0)
            {
                return false;
            }
            return true;
        }

        static void SaveFeedback(string[] feedBack, ref int count1)
        {
            string fbfile = "fbfile.txt";

            using (StreamWriter file = new StreamWriter(fbfile))
            {
                for (int x = 0; x < count1; x++)
                {
                    file.WriteLine(feedBack[x]);
                }
            }
        }

        static void GetFeedback(string[] feedBack, ref int count1)
        {
            string fbfile = "fbfile.txt";

            if (File.Exists(fbfile))
            {
                using (StreamReader file = new StreamReader(fbfile))
                {
                    string line;
                    while ((line = file.ReadLine()) != null)
                    {
                        feedBack[count1] = line;
                        count1++;
                    }
                }
            }
        }

        static void SaveRate(int[] rateArray, ref int count2)
        {
            string rAfile = "rAfile.txt";

            using (StreamWriter file = new StreamWriter(rAfile))
            {
                for (int x = 0; x < count2; x++)
                {
                    file.WriteLine(rateArray[x]);
                }
            }
        }

        static void GetRate(int[] rateArray, ref int count2)
        {
            string rAfile = "rAfile.txt";

            if (File.Exists(rAfile))
            {
                using (StreamReader file = new StreamReader(rAfile))
                {
                    string line;
                    while ((line = file.ReadLine()) != null)
                    {
                        if (int.TryParse(line, out int rate))
                        {
                            rateArray[count2] = rate;
                            count2++;
                        }
                    }
                }
            }
        }

        static void SaveDiscount(float discount)
        {
            string disfile = "disfile.txt";

            using (StreamWriter file = new StreamWriter(disfile))
            {
                file.WriteLine(discount);
            }
        }

        static void GetDiscount(ref float discount)
        {
            string disfile = "disfile.txt";

            if (File.Exists(disfile))
            {
                using (StreamReader file = new StreamReader(disfile))
                {
                    string line = file.ReadLine();
                    if (float.TryParse(line, out float parsedDiscount))
                    {
                        discount = parsedDiscount;
                    }
                }
            }
        }

        static void SaveUserData(string[] username, string[] password, string[] role, int count)
        {
            string uDfile = "uDfile.txt";

            using (StreamWriter file = new StreamWriter(uDfile))
            {
                for (int x = 0; x < count; x++)
                {
                    file.WriteLine($"{username[x]},{password[x]},{role[x]}");
                }
            }
        }

        static void GetUserData(ref string[] username, ref string[] password, ref string[] role, ref int count)
        {
            string record;
            string uDfile = "uDfile.txt";

            if (File.Exists(uDfile))
            {
                using (StreamReader file = new StreamReader(uDfile))
                {
                    while ((record = file.ReadLine()) != null)
                    {
                        username[count] = CheckField(record, 1);
                        password[count] = CheckField(record, 2);
                        role[count] = CheckField(record, 3);
                        count++;
                    }
                }
            }
        }

        static string CheckField(string record, int field)
        {
            int commacount = 1;
            string letters = "";

            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    commacount++;
                }
                else if (commacount == field)
                {
                    letters += record[x];
                }
            }

            return letters;
        }

        static void SaveProductData(string[] name1, int[] price1, int[] stock, int addProductcount)
        {
            string pDfile = "pDfile.txt";

            using (StreamWriter file = new StreamWriter(pDfile))
            {
                for (int x = 0; x < addProductcount; x++)
                {
                    file.WriteLine($"{name1[x]},{price1[x]},{stock[x]}");
                }
            }
        }

        static void GetProductData(ref string[] name1, ref int[] price1, ref int[] stock, ref int addProductcount)
        {
            string record;
            string pDfile = "pDfile.txt";

            if (File.Exists(pDfile))
            {
                using (StreamReader file = new StreamReader(pDfile))
                {
                    while ((record = file.ReadLine()) != null)
                    {
                        name1[addProductcount] = CheckField_P(record, 1);
                        price1[addProductcount] = int.Parse(CheckField_P(record, 2));
                        stock[addProductcount] = int.Parse(CheckField_P(record, 3));
                        addProductcount++;
                    }
                }
            }
        }

        static string CheckField_P(string record, int field)
        {
            int commacount = 1;
            string letters = "";

            for (int x = 0; x < record.Length; x++)
            {
                if (record[x] == ',')
                {
                    commacount++;
                }
                else if (commacount == field)
                {
                    letters += record[x];
                }
            }

            return letters;
        }


        static void Admin(int[] price1, string[] name1, int count, string[] username, string[] password, string[] role, int[] stock, string[] feedBack, ref int count1, string[] rateApp, int[] rateArray, ref int count2, ref float discount, ref int addProductcount)
        {
            string choice;
            while (true)
            {
                Console.Clear();
                Header();
                choice = AdminMenu(stock, ref addProductcount);

                if (choice == "11")
                {
                    SaveProductData(name1, price1, stock, addProductcount);
                    break;
                }
                else if (choice == "10")
                {
                    int idx = 0;
                    string newStock;
                    bool check = false;
                    string name;
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("......Add Stocks......");
                    Console.WriteLine();
                    Console.Write("Enter Product Name: ");
                    name = Console.ReadLine();

                    for (int x = 0; x < 30; x++)
                    {
                        if (name == name1[x])
                        {
                            check = true;
                            idx = x;
                            break;
                        }
                    }

                    if (!check)
                    {
                        Console.WriteLine("Wrong Product name...");
                        Console.ReadKey();
                        continue;
                    }
                    else
                    {
                        while (true)
                        {
                            bool result = true;
                            Console.Write("Enter new stock of the Product: ");
                            newStock = Console.ReadLine();

                            for (int i = 0; i < newStock.Length; i++)
                            {
                                if (!char.IsDigit(newStock[i]))
                                {
                                    result = false;
                                    break;
                                }
                            }

                            if (result)
                            {
                                int newStockInt = int.Parse(newStock);
                                stock[idx] += newStockInt;
                                Console.WriteLine();
                                break;
                            }

                            if (!result)
                            {
                                Console.WriteLine("\tInvalid Entry.\n");
                            }
                        }

                        Console.WriteLine("\tStock Successfully added.....");
                        Console.WriteLine("Press any key to continue....");
                        Console.ReadKey();
                        continue;
                    }
                }
                else if (choice == "1")
                {
                    string choice1;
                    Console.Clear();
                    choice1 = Menu1(price1, name1);
                    if (choice1 == "b" || choice1 == "B")
                    {
                        continue;
                    }
                    choice1 = Menu2(price1, name1);
                    if (choice1 == "b" || choice1 == "B")
                    {
                        continue;
                    }
                    choice1 = Menu3(price1, name1);
                    if (choice1 == "b" || choice1 == "B")
                    {
                        continue;
                    }
                    choice1 = Menu4(price1, name1, ref addProductcount);
                    if (choice1 == "b" || choice1 == "B")
                    {
                        continue;
                    }
                }
                else if (choice == "2")
                {
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("......See Stocks......");
                    Console.WriteLine();
                    Console.WriteLine("Name\t\t\t\tStock(Number of items)");

                    for (int x = 0; x < addProductcount; x++)
                    {
                        if (stock[x] <= 10)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine();
                            Console.WriteLine($"{name1[x]}\t\t\t{stock[x]}");
                            Console.WriteLine();
                            Console.ResetColor();
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine($"{name1[x]}\t\t\t{stock[x]}");
                            Console.WriteLine();
                            Console.ResetColor();
                        }
                    }

                    Console.ReadKey();
                }
                else if (choice == "3")
                {
                    int newDiscount;
                    string newDiscountStr;
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"Previous Discount is.... {discount}%");
                    Console.WriteLine();
                    Console.WriteLine("Press a key to add discount....");
                    Console.ReadKey();

                    while (true)
                    {
                        bool result = true;
                        Console.WriteLine();
                        Console.WriteLine("How much discount percentage you want to give?...");
                        newDiscountStr = Console.ReadLine();

                        for (int i = 0; i < newDiscountStr.Length; i++)
                        {
                            if (!char.IsDigit(newDiscountStr[i]))
                            {
                                result = false;
                                break;
                            }
                        }

                        if (result)
                        {
                            newDiscount = int.Parse(newDiscountStr);
                            Console.WriteLine();
                            break;
                        }

                        if (!result)
                        {
                            Console.WriteLine("\tInvalid Entry.\n");
                        }
                    }

                    if (discount + newDiscount >= 0 && discount + newDiscount <= 100)
                    {
                        discount += newDiscount;
                        Console.WriteLine("Press any key to continue....");
                        Console.WriteLine();
                        Console.WriteLine("Discount have successfully been Placed.");
                        SaveDiscount(discount);
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Invalid Input....");
                    }

                    Console.WriteLine("Press any key to continue....");
                    Console.WriteLine();
                    Console.ReadKey();
                    continue;
                }
                else if (choice == "4")
                {
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;

                    if (CheckDiscount(ref discount))
                    {
                        int newDiscount;
                        string newDiscountStr;

                        Console.WriteLine($"Previous Discount is.... {discount}%");
                        Console.WriteLine();
                        Console.WriteLine("Press a key to Remove discount....");
                        Console.ReadKey();

                        while (true)
                        {
                            bool result = true;
                            Console.WriteLine();
                            Console.WriteLine("How much discount percentage you want to remove?...");
                            newDiscountStr = Console.ReadLine();

                            for (int i = 0; i < newDiscountStr.Length; i++)
                            {
                                if (!char.IsDigit(newDiscountStr[i]))
                                {
                                    result = false;
                                    break;
                                }
                            }

                            if (result)
                            {
                                newDiscount = int.Parse(newDiscountStr);
                                Console.WriteLine();
                                break;
                            }

                            if (!result)
                            {
                                Console.WriteLine("\tInvalid Entry.\n");
                            }
                        }

                        if (discount - newDiscount >= 0)
                        {
                            discount -= newDiscount;
                            Console.WriteLine("Press any key to continue....");
                            Console.WriteLine();
                            Console.WriteLine("Discount have successfully been removed.");
                            SaveDiscount(discount);
                        }
                        else
                        {
                            Console.WriteLine($"You can't remove discount greater than {discount}%");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Discount Already 0% ...");
                    }

                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue....");
                    Console.WriteLine();
                    Console.ReadKey();
                    continue;
                }
                else if (choice == "5")
                {
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine();
                    Console.WriteLine(".......FeedBacks.......");
                    Console.WriteLine();
                    Console.WriteLine("Enter 'B' or 'b' to back...");
                    Console.WriteLine();
                    Console.WriteLine("Enter any other key to continue...");
                    Console.WriteLine();

                    string back = Console.ReadLine();

                    if (back.Equals("B", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    for (int x = 0; x < count1; x++)
                    {
                        Console.WriteLine($"{x + 1}. {feedBack[x]}");
                        Console.ReadKey();
                    }
                }
                else if (choice == "6")
                {
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine();
                    int[] c1 = { 0, 0, 0, 0 };

                    for (int x = 0; x < count2; x++)
                    {
                        switch (rateArray[x])
                        {
                            case 1:
                                c1[0]++;
                                break;
                            case 2:
                                c1[1]++;
                                break;
                            case 3:
                                c1[2]++;
                                break;
                            case 4:
                                c1[3]++;
                                break;
                        }
                    }

                    for (int x = 0; x < 4; x++)
                    {
                        Console.WriteLine($"{rateApp[x]} : {c1[x]}");
                    }

                    Console.ReadKey();
                }
                else if (choice == "7")
                {
                    int idx = 0;
                    string name, newPassword;
                    bool check = false;
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine();
                    Console.WriteLine("......Change Password......");
                    Console.Write("Enter your Username: ");
                    name = Console.ReadLine();

                    for (int x = 0; x <= count; x++)
                    {
                        if (name == username[x] && (role[x] == "admin" || role[x] == "Admin"))
                        {
                            check = true;
                            idx = x;
                            break;
                        }
                    }

                    if (!check)
                    {
                        Console.WriteLine("Username not found...");
                        Console.ReadKey();
                        continue;
                    }
                    else
                    {
                        bool newCheck = true;
                        Console.Write("Enter your new password(Greater than 3 digits): ");
                        newPassword = Console.ReadLine();

                        for (int x = 0; x < newPassword.Length; x++)
                        {
                            if (newPassword[x] == ' ')
                            {
                                Console.WriteLine();
                                newCheck = false;
                                Console.ReadKey();
                                break;
                            }
                        }

                        if (newPassword.Length <= 3 || !newCheck)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Invalid password...");
                            Console.ReadKey();
                            continue;
                        }

                        password[idx] = newPassword;
                        Console.WriteLine();
                        Console.WriteLine("Password Successfully change.....");
                        SaveUserData(username, password, role, count);
                        Console.ReadKey();
                        continue;
                    }
                }
                else if (choice == "8")
                {
                    int idx = 0;
                    string name;
                    int newPrice;
                    bool check = false;
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine();
                    Console.WriteLine("......Change Price of the Product......");
                    Console.Write("Enter Product Name: ");
                    name = Console.ReadLine();

                    for (int x = 0; x < 30; x++)
                    {
                        if (name == name1[x])
                        {
                            check = true;
                            idx = x;
                            break;
                        }
                    }

                    if (!check)
                    {
                        Console.WriteLine("Wrong Product name...");
                        Console.ReadKey();
                        continue;
                    }
                    else
                    {
                        Console.Write("Enter new Price of the Product: ");
                        newPrice = int.Parse(Console.ReadLine());
                        price1[idx] = newPrice;
                        Console.WriteLine();
                        Console.WriteLine("Price Successfully change.....");
                        Console.ReadKey();
                        continue;
                    }
                }

                else if (choice == "9")
                {
                    Console.Clear();
                    Header();
                    Console.WriteLine("\033[1;33m");
                    string name, priceee, quantit;
                    int pricee;
                    int stockk;
                    Console.WriteLine("......ADD PRODUCT......");
                    Console.WriteLine("\nEnter 'b' to go back...\n");

                    Console.WriteLine("Enter the name of the product:");
                    name = Console.ReadLine();
                    if (name.ToLower() == "b")
                    {
                        Console.WriteLine("Press any key to continue...");
                        Console.ReadKey();
                        continue;
                    }

                    foreach (char c in name)
                    {
                        if (c == ',' || c == ' ')
                        {
                            Console.WriteLine("Invalid input...");
                            Console.ReadKey();
                            break;
                        }
                    }

                    while (true)
                    {
                        bool priceResult = true;
                        Console.WriteLine("\nEnter the price of the product:");
                        priceee = Console.ReadLine();
                        foreach (char c in priceee)
                        {
                            if (!char.IsDigit(c))
                            {
                                priceResult = false;
                                break;
                            }
                        }
                        if (priceResult)
                        {
                            pricee = int.Parse(priceee);
                            while (true)
                            {
                                bool stockResult = true;
                                Console.WriteLine("\nEnter the quantity of the product:");
                                quantit = Console.ReadLine();
                                foreach (char c in quantit)
                                {
                                    if (!char.IsDigit(c))
                                    {
                                        stockResult = false;
                                        break;
                                    }
                                }
                                if (stockResult)
                                {
                                    stockk = int.Parse(quantit);
                                    break;
                                }
                                if (!stockResult)
                                {
                                    Console.WriteLine("\tInvalid Entry.\n");
                                }
                            }
                            break;
                        }
                        if (!priceResult)
                        {
                            Console.WriteLine("\tInvalid Entry.\n");
                        }
                    }

                    Console.WriteLine();
                    Console.WriteLine();
                    name1[addProductcount] = name;
                    price1[addProductcount] = pricee;
                    stock[addProductcount] = stockk;
                    addProductcount++;
                    SaveProductData(name1, price1, stock, addProductcount);
                    Console.ReadKey();
                    continue;
                }


            }
        }

        static string Menu1(int[] price1, string[] name1)
        {
            Console.Clear();
            Header();
            Console.WriteLine("\033[1;33m");
            Console.WriteLine("       [Cripsy Items]       \n");
            for (int x = 0; x < 3; x++)
            {
                Console.WriteLine($"({x + 1})Name:  {name1[x]}");
                Console.WriteLine($"   Price: Rs.{price1[x]}\n");
            }
            Console.WriteLine("(B)Home.\n");
            Console.WriteLine("Enter B or b to go to home...\n");
            Console.Write("Enter 1, 2, 3, B, or b: ");
            string option1 = Console.ReadLine();
            return option1;
        }

        static void MethodPaymentM1(int method, int[] price1, string[] name1, int[] total, int taxcard, int taxcash)
        {
            if (method == 1)
            {
                Console.WriteLine($"\nYour GST is {taxcash}%\n");
                for (int x = 0; x < 3; x++)
                {
                    total[x] = (int)(price1[x] * 0.17);
                    total[x] += price1[x];
                    Console.WriteLine($"{name1[x]} (including tax): {total[x]}");
                }
            }
            else if (method == 2)
            {
                Console.WriteLine($"\nYour GST is {taxcard}%\n");
                for (int x = 0; x < 3; x++)
                {
                    total[x] = (int)(price1[x] * 0.05);
                    total[x] += price1[x];
                    Console.WriteLine($"{name1[x]} (including tax): {total[x]}");
                }
            }
        }

        static string Menu2(int[] price1, string[] name1)
        {
            Console.Clear();
            Header();
            Console.WriteLine("\033[1;33m");
            Console.WriteLine("       [Burgers & Snacks]       \n");
            for (int x = 3; x < 9; x++)
            {
                Console.WriteLine($"({x + 1})Name:  {name1[x]}");
                Console.WriteLine($"   Price: Rs.{price1[x]}\n");
            }
            Console.WriteLine("(B)Home.\n");
            Console.WriteLine("Enter B or b to go home...\n");
            Console.Write("Enter 4, 5, 6, 7, 8, 9, B, or b: ");
            string option1 = Console.ReadLine();
            return option1;
        }

        static void MethodPaymentM2(int method, int[] price1, string[] name1, int[] total, int taxcard, int taxcash)
        {
            if (method == 1)
            {
                Console.WriteLine($"\nYour GST is {taxcash}%\n");
                for (int x = 3; x < 9; x++)
                {
                    total[x] = (int)(price1[x] * 0.17);
                    total[x] += price1[x];
                    Console.WriteLine($"{name1[x]} (including tax): {total[x]}");
                }
            }
            else if (method == 2)
            {
                Console.WriteLine($"\nYour GST is {taxcard}%\n");
                for (int x = 3; x < 9; x++)
                {
                    total[x] = (int)(price1[x] * 0.05);
                    total[x] += price1[x];
                    Console.WriteLine($"{name1[x]} (including tax): {total[x]}");
                }
            }
        }

        static string Menu3(int[] price1, string[] name1)
        {
            Console.Clear();
            Header();
            Console.WriteLine("\033[1;33m");
            Console.WriteLine("       [Beverages]       \n");
            for (int x = 9; x < 13; x++)
            {
                Console.WriteLine($"({x + 1})Name:  {name1[x]}");
                Console.WriteLine($"   Price: Rs.{price1[x]}\n");
            }
            Console.WriteLine("(B)Home.\n");
            Console.WriteLine("Enter B or b to go home...\n");
            Console.Write("Enter 10, 11, 12, 13, B, or b: ");
            string option1 = Console.ReadLine();
            return option1;
        }

        static void MethodPaymentM3(int method, int[] price1, string[] name1, int[] total, int taxcard, int taxcash)
        {
            if (method == 1)
            {
                Console.WriteLine($"\nYour GST is {taxcash}%\n");
                for (int x = 9; x < 13; x++)
                {
                    total[x] = (int)(price1[x] * 0.17);
                    total[x] += price1[x];
                    Console.WriteLine($"{name1[x]} (including tax): {total[x]}");
                }
            }
            else if (method == 2)
            {
                Console.WriteLine($"\nYour GST is {taxcard}%\n");
                for (int x = 9; x < 13; x++)
                {
                    total[x] = (int)(price1[x] * 0.05);
                    total[x] += price1[x];
                    Console.WriteLine($"{name1[x]} (including tax): {total[x]}");
                }
            }
        }

        static string Menu4(int[] price1, string[] name1, ref int addProductcount)
        {
            Console.Clear();
            Header();
            Console.WriteLine("\033[1;33m");
            Console.WriteLine("       [Siders]       \n");
            for (int x = 13; x < addProductcount; x++)
            {
                Console.WriteLine($"({x + 1})Name:  {name1[x]}");
                Console.WriteLine($"   Price: Rs.{price1[x]}\n");
            }
            Console.WriteLine("(B)Home.\n");
            Console.WriteLine("Enter B or b to go home...\n");
            Console.Write("Enter your option: ");
            string option1 = Console.ReadLine();
            return option1;
        }

        static void MethodPaymentM4(int method, int[] price1, string[] name1, int[] total, int taxcard, int taxcash, ref int addProductcount)
        {
            if (method == 1)
            {
                Console.WriteLine($"\nYour GST is {taxcash}%\n");
                for (int x = 13; x < addProductcount; x++)
                {
                    total[x] = (int)(price1[x] * 0.17);
                    total[x] += price1[x];
                    Console.WriteLine($"{name1[x]} (including tax): {total[x]}");
                }
            }
            else if (method == 2)
            {
                Console.WriteLine($"\nYour GST is {taxcard}%\n");
                for (int x = 13; x < addProductcount; x++)
                {
                    total[x] = (int)(price1[x] * 0.05);
                    total[x] += price1[x];
                    Console.WriteLine($"{name1[x]} (including tax): {total[x]}");
                }
            }
        }

        static void Menu(int[] price1, string[] name1, int count, string[] username, string[] password, string[] role, int[] stock, string[] feedBack, ref int count1, string[] rateApp, int[] rateArray, ref int count2, ref float discount, ref int addProductcount)
        {
            int taxcard = 5, taxcash = 17;
            string option;
            string option1;
            int[] total = new int[30];

            while (true)
            {
                Console.Clear();
                Header();
                option = CustomerMenu(ref discount);

                if (option == "1")
                {
                    option1 = Menu1(price1, name1);

                    if (option1.ToLower() == "b")
                    {
                        continue;
                    }
                    else if (option1 == "1" || option1 == "2" || option1 == "3")
                    {
                        int method;
                        Console.Write("Enter payment method (1.Cash / 2.Card): ");
                        int.TryParse(Console.ReadLine(), out method);
                        MethodPaymentM1(method, price1, name1, total, taxcard, taxcash);
                    }

                    Console.WriteLine();
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                    Console.WriteLine();
                    Console.WriteLine();
                }
                else if (option == "6")
                {
                    Console.Clear();
                    Header();
                    Console.WriteLine("\033[1;33m");
                    string back;
                    Console.WriteLine("Enter 'B' or 'b' to back...\n");
                    Console.WriteLine("Enter any other key to continue...\n");
                    back = Console.ReadLine();
                    if (back.ToLower() == "b")
                    {
                        continue;
                    }
                    Console.WriteLine("\nFeedback about App....");
                    feedBack[count1] = Console.ReadLine();
                    count1++;

                    SaveFeedback(feedBack,ref count1);
                }
                else if (option == "7")
                {
                    int idx = 0;
                    string name, newPassword;
                    bool check = false;
                    Console.Clear();
                    Header();
                    Console.WriteLine("\033[1;33m");
                    Console.WriteLine("\n......Change Password......");
                    Console.Write("Enter your Username: ");
                    name = Console.ReadLine();
                    for (int x = 0; x <= count; x++)
                    {
                        if (name == username[x] && (role[x] == "customer" || role[x] == "Customer"))
                        {
                            check = true;
                            idx = x;
                            break;
                        }
                    }
                    if (!check)
                    {
                        Console.WriteLine("Username not found...");
                        Console.ReadKey();
                        continue;
                    }
                    else
                    {
                        bool newcheck = true;
                        Console.Write("Enter your new password (Greater than 3 digits): ");
                        newPassword = Console.ReadLine();
                        for (int x = 0; x < newPassword.Length; x++)
                        {
                            if (newPassword[x] == ' ')
                            {
                                Console.WriteLine();
                                newcheck = false;
                                Console.ReadKey();
                                break;
                            }
                        }
                        if (newPassword.Length <= 3 || !newcheck)
                        {
                            Console.WriteLine();
                            Console.WriteLine("Invalid password...");
                            Console.ReadKey();
                            continue;
                        }
                        password[idx] = newPassword;
                        Console.WriteLine();
                        Console.WriteLine("Password Successfully changed.....");
                        SaveUserData(username, password, role, count);
                        Console.ReadKey();
                        continue;
                    }
                }
                else if (option == "8")
                {
                    SaveProductData(name1, price1, stock, addProductcount);
                    break;
                }
                else if (option == "2")
                {
                    option1 = Menu2(price1, name1);
                    if (option1.ToLower() == "b")
                    {
                        continue;
                    }
                    if (option1 == "4" || option1 == "5" || option1 == "6" || option1 == "7" || option1 == "8" || option1 == "9")
                    {
                        int method;
                        Console.Write("Enter payment method (1.Cash / 2.Card): ");
                        int.TryParse(Console.ReadLine(), out method);
                        MethodPaymentM2(method, price1, name1, total, taxcard, taxcash);
                    }
                    Console.WriteLine("Press any key to continue...");
                    Console.WriteLine();
                    Console.ReadKey();
                    Console.WriteLine();
                    Console.WriteLine();
                }
                else if (option == "3")
                {
                    option1 = Menu3(price1, name1);
                    if (option1.ToLower() == "b")
                    {
                        continue;
                    }
                    else if (option1 == "10" || option1 == "11" || option1 == "12" || option1 == "13")
                    {
                        int method;
                        Console.Write("Enter payment method (1.Cash / 2.Card): ");
                        int.TryParse(Console.ReadLine(), out method);
                        MethodPaymentM3(method, price1, name1, total, taxcard, taxcash);
                    }
                    Console.WriteLine("Press any key to continue...");
                    Console.WriteLine();
                    Console.ReadKey();
                    Console.WriteLine();
                    Console.WriteLine();
                }
                else if (option == "4")
                {
                    option1 = Menu4(price1, name1, ref addProductcount);
                    if (option1.ToLower() == "b")
                    {
                        continue;
                    }
                    if (option1 == "14" || option1 == "15" || option1 == "16" || option1 == "17" || option1 == "18" || option1 == "19" || option1 == "20" || option1 == "21")
                    {
                        int method;
                        Console.Write("Enter payment method (1.Cash / 2.Card): ");
                        int.TryParse(Console.ReadLine(), out method);
                        MethodPaymentM4(method, price1, name1, total, taxcard, taxcash, ref addProductcount);
                    }
                    Console.WriteLine("Press any key to continue...");
                    Console.WriteLine();
                    Console.ReadKey();
                    Console.WriteLine();
                    Console.WriteLine();
                }

                else if (option == "5")
                {
                    string payment;
                    int total1 = 0;
                    Console.Clear();
                    Header();
                    Console.ForegroundColor = ConsoleColor.Yellow;

                    int number = 0;
                    int quantity = 0;
                    while (true)
                    {
                        Console.WriteLine("Enter '00' to go back... ");
                        Console.WriteLine();
                        Console.Write("Enter Product number: ");
                        int.TryParse(Console.ReadLine(), out number);
                        Console.WriteLine();
                        if (number >= 1 && number <= addProductcount)
                        {
                            Console.Write("Enter quantity you want to buy: ");
                            int.TryParse(Console.ReadLine(), out quantity);

                            if (quantity > stock[number - 1])
                            {
                                Console.WriteLine($"We have only {stock[number - 1]} products....\n");
                                Console.ReadKey();
                                continue;
                            }

                            Console.WriteLine();
                            Console.Write("Enter payment method(1. card / 2. cash): ");
                            payment = Console.ReadLine();
                            Console.WriteLine();

                            if (payment == "1")
                            {
                                string check;
                                Console.WriteLine($"Your tax is {taxcard}%\n");
                                Console.WriteLine("Name\t\t\t\tPrice\t\t\t\tQuantity\t\t\t\tDiscount");

                                Console.WriteLine($"{name1[number - 1]}\t\t\t{price1[number - 1]}\t\t\t\t{quantity}\t\t\t\t\t{discount}%");

                                total1 = (int)(quantity * price1[number - 1]) + (int)((quantity * price1[number - 1]) * 0.05);

                                if (discount >= 0)
                                {
                                    total1 = total1 - (int)((price1[number - 1] * discount) / 100);
                                }

                                Console.WriteLine($"TotalPrice:\t\t\t{total1}\n");

                                stock[number - 1] = stock[number - 1] - quantity;

                                Console.WriteLine("Enter 'E' or 'e' if you end shopping...\n");
                                Console.WriteLine("Enter 'R' or 'r' if you want to rate Meal...\n");
                                Console.WriteLine("Enter any other key to continue shopping...");

                                check = Console.ReadLine();

                                if (check.ToLower() == "e")
                                {
                                    SaveProductData(name1, price1, stock, addProductcount);
                                    Console.Clear();
                                    EndScreen();
                                    System.Threading.Thread.Sleep(1700);
                                    Environment.Exit(0);
                                }
                                else if (check.ToLower() == "r")
                                {
                                    Console.Clear();
                                    Header();
                                    Console.ForegroundColor = ConsoleColor.Green;

                                    for (int x = 0; x <= 3; x++)
                                    {
                                        Console.WriteLine($"{x + 1}. {rateApp[x]}");
                                    }

                                    Console.WriteLine();
                                    int.TryParse(Console.ReadLine(), out rateArray[count2]);
                                    count2++;

                                    SaveRate(rateArray,ref count2);
                                }
                            }
                            else if (payment == "2")
                            {
                                string check;
                                Console.WriteLine($"Your tax is {taxcash}%\n");
                                Console.WriteLine("Name\t\t\t\tPrice\t\t\t\tQuantity\t\t\t\tDiscount");

                                Console.WriteLine($"{name1[number - 1]}\t\t\t{price1[number - 1]}\t\t\t\t{quantity}\t\t\t\t\t{discount}%");

                                total1 = (int)(quantity * price1[number - 1]) + (int)((quantity * price1[number - 1]) * 0.17);

                                if (discount >= 0)
                                {
                                    total1 = (int)(total1 - ((price1[number - 1] * discount) / 100));
                                }

                                Console.WriteLine($"TotalPrice:\t\t\t{total1}\n");

                                stock[number - 1] = stock[number - 1] - quantity;

                                Console.WriteLine("Enter 'E' or 'e' if you end shopping...\n");
                                Console.WriteLine("Enter 'R' or 'r' if you want to rate Meal...\n");
                                Console.WriteLine("Enter any other key to continue shopping...");

                                check = Console.ReadLine();

                                if (check.ToLower() == "e")
                                {
                                    SaveProductData(name1, price1, stock, addProductcount);
                                    Console.Clear();
                                    EndScreen();
                                    System.Threading.Thread.Sleep(1700);
                                    Environment.Exit(0);
                                }
                                else if (check.ToLower() == "r")
                                {
                                    Console.Clear();
                                    Header();
                                    Console.ForegroundColor = ConsoleColor.Yellow;

                                    for (int x = 0; x <= 3; x++)
                                    {
                                        Console.WriteLine($"{x + 1}. {rateApp[x]}");
                                    }

                                    Console.WriteLine();
                                    int.TryParse(Console.ReadLine(), out rateArray[count2]);
                                    count2++;

                                    SaveRate(rateArray,ref count2);
                                }
                            }
                            Console.ReadKey();
                            break;
                        }
                        else if (number == 00)
                        {
                            break;
                        }
                        else
                        {
                            Console.WriteLine("Invalid Product number...\n");
                            Console.ReadKey();
                        }
                    }
                }


            }
        }

        static void EndScreen()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"
        
                             ________  _____    _   ____ __    __  ______  __  __
                            /_  __/ / / /   |  / | / / //_/    \ \/ / __ \/ / / /
                             / / / /_/ / /| | /  |/ / ,<        \  / / / / / / / 
                            / / / __  / ___ |/ /|  / /| |       / / /_/ / /_/ /  
                           /_/ /_/ /_/_/  |_/_/ |_/_/ |_|      /_/\____/\____/   
                                                                                 

");
        }

    }
}



